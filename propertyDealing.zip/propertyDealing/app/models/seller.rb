class Seller < ApplicationRecord
	has_one_attached :avatar
end
