class HomeController < ApplicationController
  def index
  end

  def register
  end

  def login
  end

  def about
  end

  def services
  end

  def contact
  end
end
