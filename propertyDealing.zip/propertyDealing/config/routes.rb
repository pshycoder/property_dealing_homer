Rails.application.routes.draw do
  devise_for :users
  devise_scope :user do
  get '/users/sign_out' => 'devise/sessions#destroy'
  end
  resources :sellers
  root 'home#index'
  get 'home/index'
  get 'home/register'
  get 'home/login'
  get 'home/about'
  get 'home/services'
  get 'home/contact'


  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
